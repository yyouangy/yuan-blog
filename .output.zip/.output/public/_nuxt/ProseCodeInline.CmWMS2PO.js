import{_ as o,o as n,c as r,a3 as c}from"./entry.B_IB470g.js";const s={};function t(e,a){return n(),r("code",null,[c(e.$slots,"default")])}const _=o(s,[["render",t]]);export{_ as default};
