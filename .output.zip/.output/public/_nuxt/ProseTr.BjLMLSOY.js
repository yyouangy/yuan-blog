import{_ as r,o,c as t,a3 as s}from"./entry.B_IB470g.js";const c={};function n(e,a){return o(),t("tr",null,[s(e.$slots,"default")])}const _=r(c,[["render",n]]);export{_ as default};
