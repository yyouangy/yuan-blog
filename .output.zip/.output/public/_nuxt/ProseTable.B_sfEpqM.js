import{_ as o,o as r,c as t,a3 as a}from"./entry.B_IB470g.js";const s={};function c(e,n){return r(),t("table",null,[a(e.$slots,"default")])}const _=o(s,[["render",c]]);export{_ as default};
