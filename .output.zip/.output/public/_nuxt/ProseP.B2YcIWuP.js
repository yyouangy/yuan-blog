import{_ as o,o as r,c as s,a3 as t}from"./entry.B_IB470g.js";const c={};function n(e,a){return r(),s("p",null,[t(e.$slots,"default")])}const _=o(c,[["render",n]]);export{_ as default};
