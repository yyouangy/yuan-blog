import{_ as o,o as t,c,a3 as r}from"./entry.B_IB470g.js";const s={};function n(e,a){return t(),c("blockquote",null,[r(e.$slots,"default")])}const _=o(s,[["render",n]]);export{_ as default};
