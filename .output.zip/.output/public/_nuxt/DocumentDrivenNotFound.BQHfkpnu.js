import{f as n,J as e}from"./entry.B_IB470g.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
