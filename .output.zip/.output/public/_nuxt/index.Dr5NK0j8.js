import{f as e,s as o}from"./entry.B_IB470g.js";const n=e({__name:"index",setup(r){return o().replace("/blog"),()=>{}}});export{n as default};
