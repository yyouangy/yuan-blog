module.exports = {
    apps: [{
        name: 'NuxtAppName', // 设置启动项目名称
        exec_mode: 'cluster',
        instances: 'max',
        // 注意这里的相对路径
        script: './.output/server/index.mjs'
    }]
}