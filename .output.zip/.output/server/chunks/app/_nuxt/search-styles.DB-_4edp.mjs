const search_vue_vue_type_style_index_0_lang = ".search-input{background-color:var(--input-bg);border-bottom:2px solid var(--common-bd);outline:none;padding:1em;transition:var(--common-transition);width:100%}.search-input:focus{border-color:currentcolor}";

const searchStyles_DB_4edp = [search_vue_vue_type_style_index_0_lang];

export { searchStyles_DB_4edp as default };
//# sourceMappingURL=search-styles.DB-_4edp.mjs.map
