import { _ as __nuxt_component_0 } from './nuxt-link-AmAnS3-O.mjs';
import { _ as _sfc_main$1 } from './Cell-DOBFdHeo.mjs';
import { a as useRoute } from '../server.mjs';
import { defineComponent, ref, withAsyncContext, withCtx, createTextVNode, unref, useSSRContext } from 'vue';
import { q as queryContent } from './query-DH7EuNbE.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderList } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'shiki/core';
import '@shikijs/transformers';
import 'unified';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'micromark-util-sanitize-uri';
import 'slugify';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'hast-util-to-string';
import 'github-slugger';
import 'detab';
import 'remark-emoji';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import './index-DoJ4kpbC.mjs';
import 'date-fns';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './preview-BeDjujCI.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "[tag]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const route = useRoute();
    const tag = route.params.tag;
    const queryResult = ref();
    queryResult.value = ([__temp, __restore] = withAsyncContext(() => queryContent().where({
      tags: {
        $contains: tag
      }
    }).find()), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_cell = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><h1 class="text-title mb-2em">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/tags",
        class: "hover"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Tags `);
          } else {
            return [
              createTextVNode(" Tags ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` / ${ssrInterpolate(unref(tag))}</h1><ul><!--[-->`);
      ssrRenderList(unref(queryResult), (article) => {
        _push(ssrRenderComponent(_component_cell, {
          key: article._path,
          article
        }, null, _parent));
      });
      _push(`<!--]-->`);
      if (unref(queryResult).length === 0) {
        _push(`<h1 class="text-2xl text-center"> Not Found Any Document\u{1F617} </h1>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</ul></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tags/[tag].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_tag_-Cg5i6ata.mjs.map
