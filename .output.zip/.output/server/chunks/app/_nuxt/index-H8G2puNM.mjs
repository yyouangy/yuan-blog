import { _ as __nuxt_component_0 } from './nuxt-link-AmAnS3-O.mjs';
import { q as queryContent } from './query-DH7EuNbE.mjs';
import { defineComponent, withAsyncContext, unref, withCtx, createVNode, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderList, ssrRenderStyle, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'shiki/core';
import '@shikijs/transformers';
import 'unified';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'micromark-util-sanitize-uri';
import 'slugify';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'hast-util-to-string';
import 'github-slugger';
import 'detab';
import 'remark-emoji';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import '../server.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './preview-BeDjujCI.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const contentQuery = ([__temp, __restore] = withAsyncContext(() => queryContent().find()), __temp = await __temp, __restore(), __temp);
    const tagsContent = contentQuery.filter((i) => i.tags).filter((i) => {
      const regex = /(readme|about)\.md$/i;
      return !regex.test(i._file);
    }).reduce((counts, post) => {
      for (const tag of post.tags) {
        if (counts[tag])
          counts[tag]++;
        else
          counts[tag] = 1;
      }
      return counts;
    }, {});
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      _push(`<!--[--><h1 class="text-title mb-2em font-bold"> Tags </h1><ul class="flex gap-1em flex-wrap"><!--[-->`);
      ssrRenderList(unref(tagsContent), (value, key, index) => {
        _push(`<li slide-enter style="${ssrRenderStyle({ "--stagger": index + 1 })}" class="px-2 bg-gray-400:20 rd-1">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/tags/${key}`,
          class: "flex gap-2"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<span class="hover"${_scopeId}>#${ssrInterpolate(key)}</span><span${_scopeId}>${ssrInterpolate(value)}</span>`);
            } else {
              return [
                createVNode("span", { class: "hover" }, "#" + toDisplayString(key), 1),
                createVNode("span", null, toDisplayString(value), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/tags/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-H8G2puNM.mjs.map
