import { _ as _sfc_main$1 } from './Cell-DOBFdHeo.mjs';
import { defineComponent, ref, watch, unref, useSSRContext } from 'vue';
import { q as queryContent } from './query-DH7EuNbE.mjs';
import { ssrRenderAttr, ssrRenderList, ssrRenderComponent } from 'vue/server-renderer';
import { u as useDebounceFn } from './index-D6hFWh2B.mjs';
import './nuxt-link-AmAnS3-O.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'shiki/core';
import '@shikijs/transformers';
import 'unified';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'micromark-util-sanitize-uri';
import 'slugify';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'hast-util-to-string';
import 'github-slugger';
import 'detab';
import 'remark-emoji';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import '../server.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './index-DoJ4kpbC.mjs';
import 'date-fns';
import './preview-BeDjujCI.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "search",
  __ssrInlineRender: true,
  setup(__props) {
    const searchValue = ref("");
    const queryResult = ref();
    const getQueryResult = useDebounceFn(async () => {
      if (!searchValue.value) {
        queryResult.value = [];
        return;
      }
      queryResult.value = await queryContent().where({
        $or: [
          { title: { $regex: new RegExp(`.*${searchValue.value}.*`, "i") } },
          {
            description: {
              $regex: new RegExp(`.*${searchValue.value}.*`, "i")
            }
          },
          {
            tags: {
              $contains: searchValue.value
            }
          }
        ]
      }).find();
    }, 600);
    watch(searchValue, getQueryResult);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_cell = _sfc_main$1;
      _push(`<!--[--><h1 class="text-title mb-2em font-bold"> Search </h1><div class="slide-enter-content"><input${ssrRenderAttr("value", unref(searchValue))} placeholder="Search post title / description / tag" class="search-input mb-2em"><ul><!--[-->`);
      ssrRenderList(unref(queryResult), (article, index) => {
        _push(ssrRenderComponent(_component_cell, {
          key: article._path,
          article,
          "slide-enter": "",
          style: { "--stagger": index + 1 }
        }, null, _parent));
      });
      _push(`<!--]--></ul></div><!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/search.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=search-DTgapuhK.mjs.map
