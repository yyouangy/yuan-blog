import { _ as _sfc_main$1 } from './Cell-DOBFdHeo.mjs';
import { defineComponent, withAsyncContext, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderStyle, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { p as projectList } from '../server.mjs';
import { a as getPosts } from './index-DoJ4kpbC.mjs';
import './nuxt-link-AmAnS3-O.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'shiki/core';
import '@shikijs/transformers';
import 'unified';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'micromark-util-sanitize-uri';
import 'slugify';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'hast-util-to-string';
import 'github-slugger';
import 'detab';
import 'remark-emoji';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './query-DH7EuNbE.mjs';
import './preview-BeDjujCI.mjs';
import 'date-fns';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "notes",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const posts = Object.assign({}, ...([__temp, __restore] = withAsyncContext(async () => Promise.all(projectList.map(async (item) => ({ [item.floder]: await getPosts(`notes/${item.floder}`) })))), __temp = await __temp, __restore(), __temp));
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Cell = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(_attrs)}><!--[-->`);
      ssrRenderList(unref(projectList), (series, index) => {
        _push(`<article slide-enter style="${ssrRenderStyle({ "--stagger": index + 1 })}"><div class="text-center mt-2em mb-1em text-gray-700:60" font-bold text-lg>${ssrInterpolate(series.name)}</div><div class="grid grid-cols-1 md:grid-cols-2 gap-1em"><!--[-->`);
        ssrRenderList(unref(posts)[series.floder], (article, index2) => {
          _push(`<div>`);
          _push(ssrRenderComponent(_component_Cell, {
            isNotes: true,
            article,
            "slide-enter": "",
            style: { "--stagger": index2 + 1 }
          }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div></article>`);
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/notes.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=notes-D77iMIfB.mjs.map
