const ProsePre_vue_vue_type_style_index_0_lang = "pre code .line{display:block;min-height:1rem}";

const ProsePreStyles_CQChdepm = [ProsePre_vue_vue_type_style_index_0_lang];

export { ProsePreStyles_CQChdepm as default };
//# sourceMappingURL=ProsePre-styles.CQChdepm.mjs.map
