import { _ as _sfc_main$1 } from './Cell-DOBFdHeo.mjs';
import { defineComponent, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderStyle, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PostList",
  __ssrInlineRender: true,
  props: ["posts"],
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Cell = _sfc_main$1;
      _push(`<ul${ssrRenderAttrs(_attrs)}><!--[-->`);
      ssrRenderList(__props.posts, (article, index) => {
        _push(`<!--[-->`);
        if (article.isMarked) {
          _push(`<div class="relative pointer-events-none select-none h-20" slide-enter style="${ssrRenderStyle({ "--stagger": index + 1 })}"><span class="text-8em font-bold op-15 absolute -top-0.2em -left-0.3em color-transparent text-stroke-2 text-stroke-hex-aaa">${ssrInterpolate(article.year)}</span></div>`);
        } else {
          _push(ssrRenderComponent(_component_Cell, {
            article,
            "slide-enter": "",
            style: { "--stagger": index + 1 }
          }, null, _parent));
        }
        _push(`<!--]-->`);
      });
      _push(`<!--]--></ul>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/PostList.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=PostList-DMAInqzv.mjs.map
