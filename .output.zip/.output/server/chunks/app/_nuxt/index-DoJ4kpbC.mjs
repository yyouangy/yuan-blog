import { q as queryContent } from './query-DH7EuNbE.mjs';
import { parseISO, format } from 'date-fns';

function formattedDate(date) {
  if (!date)
    return "";
  const dateObject = parseISO(date);
  const formattedResult = format(dateObject, "yyyy/MM/dd");
  return formattedResult;
}
function insertYearToPosts(posts) {
  let currentYear = -1;
  return posts.reduce((posts2, post) => {
    const year = new Date(post.date).getFullYear();
    if (year !== currentYear && !isNaN(year)) {
      posts2.push({
        isMarked: true,
        year
      });
      currentYear = year;
    }
    posts2.push(post);
    return posts2;
  }, []);
}
async function getIncludedYearPosts(dirName) {
  const result = await queryContent(dirName).sort({ date: -1 }).find();
  return insertYearToPosts(result);
}
async function getPosts(dirName) {
  return await queryContent(dirName).sort({ date: -1 }).find();
}

export { getPosts as a, formattedDate as f, getIncludedYearPosts as g };
//# sourceMappingURL=index-DoJ4kpbC.mjs.map
