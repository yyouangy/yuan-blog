const __uno = "#--unocss--{layer:__ALL__}";

export { __uno as _ };
//# sourceMappingURL=entry-styles-6.mjs-C-5r91Yz.mjs.map
