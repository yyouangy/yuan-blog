import { _ as __uno } from './entry-styles-6.mjs-C-5r91Yz.mjs';

const unocssStyles_8_MInZPp = [__uno];

export { unocssStyles_8_MInZPp as default };
//# sourceMappingURL=unocss-styles.8_MInZPp.mjs.map
