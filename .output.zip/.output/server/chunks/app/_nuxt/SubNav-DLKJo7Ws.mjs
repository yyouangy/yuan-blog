import { a as useRoute, b as useRouter, s as subNavLinks } from '../server.mjs';
import { defineComponent, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SubNav",
  __ssrInlineRender: true,
  setup(__props) {
    const route = useRoute();
    const { path } = route;
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<ul${ssrRenderAttrs(mergeProps({ class: "flex gap-1em mb-2em" }, _attrs))}><!--[-->`);
      ssrRenderList(unref(subNavLinks), (item) => {
        _push(`<li class="${ssrRenderClass([unref(path) === item.path ? "text-deep font-bold" : "deep-hover", "cursor-pointer"])}"><span class="text-title">${ssrInterpolate(item.title)}</span></li>`);
      });
      _push(`<!--]--></ul>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SubNav.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=SubNav-DLKJo7Ws.mjs.map
