import { _ as _sfc_main$1 } from './SubNav-DLKJo7Ws.mjs';
import { _ as _sfc_main$2 } from './PostList-DMAInqzv.mjs';
import { defineComponent, withAsyncContext, unref, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { g as getIncludedYearPosts } from './index-DoJ4kpbC.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'shiki/core';
import '@shikijs/transformers';
import 'unified';
import 'mdast-util-to-string';
import 'micromark';
import 'unist-util-stringify-position';
import 'micromark-util-character';
import 'micromark-util-chunked';
import 'micromark-util-resolve-all';
import 'micromark-util-sanitize-uri';
import 'slugify';
import 'remark-parse';
import 'remark-rehype';
import 'remark-mdc';
import 'hast-util-to-string';
import 'github-slugger';
import 'detab';
import 'remark-emoji';
import 'remark-gfm';
import 'rehype-external-links';
import 'rehype-sort-attribute-values';
import 'rehype-sort-attributes';
import 'rehype-raw';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './Cell-DOBFdHeo.mjs';
import './nuxt-link-AmAnS3-O.mjs';
import './query-DH7EuNbE.mjs';
import './preview-BeDjujCI.mjs';
import 'date-fns';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "life",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const posts = ([__temp, __restore] = withAsyncContext(() => getIncludedYearPosts("life")), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_sub_nav = _sfc_main$1;
      const _component_post_list = _sfc_main$2;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_sub_nav, null, null, _parent));
      _push(ssrRenderComponent(_component_post_list, { posts: unref(posts) }, null, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/life.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=life-iLmTJD8A.mjs.map
