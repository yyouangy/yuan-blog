const client_manifest = {
  "_Cell.vue.B4kp0Hed.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Cell.vue.B4kp0Hed.js",
    "imports": [
      "_nuxt-link.B5TFTaXi.js",
      "_index.DmQH33Or.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_ContentRendererMarkdown.vue.CBVWc_lB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ContentRendererMarkdown.vue.CBVWc_lB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.BsYmvPZw.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "_NavBar.vue.BcxCuZeb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NavBar.vue.BcxCuZeb.js",
    "imports": [
      "_nuxt-link.B5TFTaXi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_PostList.vue.BJAgizMw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "PostList.vue.BJAgizMw.js",
    "imports": [
      "_Cell.vue.B4kp0Hed.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_SubNav.vue.CutUwA-u.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "SubNav.vue.CutUwA-u.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_asyncData.NVQsfYZl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "asyncData.NVQsfYZl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.0H1nq9AP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.0H1nq9AP.js",
    "imports": [
      "_index.Cw5xeYJd.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.BsYmvPZw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.BsYmvPZw.js"
  },
  "_index.Cw5xeYJd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Cw5xeYJd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.DmQH33Or.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.DmQH33Or.js",
    "imports": [
      "_query.BOJ__k2B.js"
    ]
  },
  "_nuxt-link.B5TFTaXi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.B5TFTaXi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_preview.CxuQdA9n.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "preview.CxuQdA9n.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_query.BOJ__k2B.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "query.BOJ__k2B.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.CxuQdA9n.js"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/content/dist/runtime/legacy/composables/client-db.js"
    ]
  },
  "components/content/ProseCode.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseCode.DXC4gkK8.js",
    "src": "components/content/ProseCode.vue",
    "isDynamicEntry": true,
    "imports": [
      "_index.0H1nq9AP.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.Cw5xeYJd.js"
    ]
  },
  "components/content/ProseImg.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseImg.C1EIekAS.js",
    "src": "components/content/ProseImg.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/components/NavBar.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NavBar.DJsjoJVj.js",
    "src": "layouts/components/NavBar.vue",
    "isDynamicEntry": true,
    "imports": [
      "_NavBar.vue.BcxCuZeb.js",
      "_nuxt-link.B5TFTaXi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.Bp3Uhft9.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "_NavBar.vue.BcxCuZeb.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.B5TFTaXi.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentDoc.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ContentDoc.DdLMZHc9.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentDoc.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue",
      "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue",
      "_ContentRendererMarkdown.vue.CBVWc_lB.js",
      "_index.BsYmvPZw.js",
      "_preview.CxuQdA9n.js",
      "_asyncData.NVQsfYZl.js",
      "_query.BOJ__k2B.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentList.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ContentList.CcEaWj_k.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentList.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.NVQsfYZl.js",
      "_query.BOJ__k2B.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentNavigation.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ContentNavigation.BX7Johsn.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentNavigation.vue",
    "isDynamicEntry": true,
    "imports": [
      "_asyncData.NVQsfYZl.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.CxuQdA9n.js",
      "_query.BOJ__k2B.js",
      "_nuxt-link.B5TFTaXi.js"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/content/dist/runtime/legacy/composables/client-db.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ContentQuery.DwNT5pwl.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue",
    "isDynamicEntry": true,
    "imports": [
      "_asyncData.NVQsfYZl.js",
      "_query.BOJ__k2B.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ContentRenderer.BT2_yBn2.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ContentRendererMarkdown.vue.CBVWc_lB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.BsYmvPZw.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentRendererMarkdown.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ContentRendererMarkdown.BFV79DGY.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentRendererMarkdown.vue",
    "isDynamicEntry": true,
    "imports": [
      "_ContentRendererMarkdown.vue.CBVWc_lB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.BsYmvPZw.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/ContentSlot.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ContentSlot.BEPWh-nm.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/ContentSlot.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/DocumentDrivenEmpty.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DocumentDrivenEmpty.CxyhJW21.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/DocumentDrivenEmpty.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/DocumentDrivenNotFound.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "DocumentDrivenNotFound.BQHfkpnu.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/DocumentDrivenNotFound.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/Markdown.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Markdown._yyuW1jH.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/Markdown.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/@nuxt/content/dist/runtime/components/ContentSlot.vue",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseCodeInline.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseCodeInline.CmWMS2PO.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProseCodeInline.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxt/content/dist/runtime/components/Prose/ProsePre.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProsePre.D6CzfON0.js",
    "src": "node_modules/@nuxt/content/dist/runtime/components/Prose/ProsePre.vue",
    "isDynamicEntry": true,
    "imports": [
      "components/content/ProseCode.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.0H1nq9AP.js",
      "_index.Cw5xeYJd.js"
    ],
    "css": []
  },
  "ProsePre.CchFRBtv.css": {
    "file": "ProsePre.CchFRBtv.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/content/dist/runtime/legacy/composables/client-db.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-db.6_nmqoP5.js",
    "src": "node_modules/@nuxt/content/dist/runtime/legacy/composables/client-db.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_query.BOJ__k2B.js",
      "_index.BsYmvPZw.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-404.Cu5yWfri.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.B5TFTaXi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-404.CoUbADi5.css": {
    "file": "error-404.CoUbADi5.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-500.ByUnIIFr.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-500.BXQ_YkC0.css": {
    "file": "error-500.BXQ_YkC0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseA.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseA.VBHwfvYW.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseA.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.B5TFTaXi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseBlockquote.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseBlockquote.BC2GK8P8.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseBlockquote.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseEm.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseEm.Db02xX5Y.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseEm.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH1.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseH1.CCehrrzJ.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH1.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseH2.HMGOdPWQ.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH2.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH3.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseH3.BDX67E7s.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH3.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH4.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseH4.BAjHjmbd.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH4.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH5.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseH5.BTqAooV5.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH5.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH6.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseH6.BTQfZ07R.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseH6.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseHr.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseHr.Bo23zsq-.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseHr.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseLi.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseLi.KE-vJlDh.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseLi.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseOl.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseOl.CWVRqbq9.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseOl.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseP.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseP.B2YcIWuP.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseP.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseScript.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseScript.zjDMTBkd.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseScript.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseStrong.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseStrong.-bXB3C2z.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseStrong.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTable.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseTable.B_sfEpqM.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTable.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTbody.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseTbody.CAH_sb8T.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTbody.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTd.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseTd.BzHvzIIO.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTd.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTh.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseTh.lLPXbSBu.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTh.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseThead.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseThead.CdMi8TUe.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseThead.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTr.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseTr.BjLMLSOY.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseTr.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseUl.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ProseUl.BSulpriZ.js",
    "src": "node_modules/@nuxtjs/mdc/dist/runtime/components/prose/ProseUl.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.B_IB470g.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "dynamicImports": [
      "layouts/components/NavBar.vue",
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "css": [
      "entry.CraqZk1r.css"
    ],
    "_globalCSS": true
  },
  "entry.CraqZk1r.css": {
    "file": "entry.CraqZk1r.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/[...404].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...404_.I9FAxARD.js",
    "src": "pages/[...404].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/@nuxt/content/dist/runtime/components/ContentDoc.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue",
      "_ContentRendererMarkdown.vue.CBVWc_lB.js",
      "_index.BsYmvPZw.js",
      "_preview.CxuQdA9n.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue",
      "_asyncData.NVQsfYZl.js",
      "_query.BOJ__k2B.js"
    ]
  },
  "pages/blog.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "blog.BncZwsZI.js",
    "src": "pages/blog.vue",
    "isDynamicEntry": true,
    "imports": [
      "_PostList.vue.BJAgizMw.js",
      "_index.DmQH33Or.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Cell.vue.B4kp0Hed.js",
      "_nuxt-link.B5TFTaXi.js",
      "_query.BOJ__k2B.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.gipVfYku.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/@nuxt/content/dist/runtime/components/ContentDoc.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue",
      "_ContentRendererMarkdown.vue.CBVWc_lB.js",
      "_index.BsYmvPZw.js",
      "_preview.CxuQdA9n.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue",
      "_asyncData.NVQsfYZl.js",
      "_query.BOJ__k2B.js"
    ]
  },
  "pages/life.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "life.DlRYHGqz.js",
    "src": "pages/life.vue",
    "isDynamicEntry": true,
    "imports": [
      "_SubNav.vue.CutUwA-u.js",
      "_PostList.vue.BJAgizMw.js",
      "_index.DmQH33Or.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Cell.vue.B4kp0Hed.js",
      "_nuxt-link.B5TFTaXi.js",
      "_query.BOJ__k2B.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "pages/notes.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "notes.C6L0ngSj.js",
    "src": "pages/notes.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Cell.vue.B4kp0Hed.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.DmQH33Or.js",
      "_nuxt-link.B5TFTaXi.js",
      "_query.BOJ__k2B.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "pages/p/[...post].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_...post_.iIKFZ0nM.js",
    "src": "pages/p/[...post].vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_nuxt-link.B5TFTaXi.js",
      "_index.DmQH33Or.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentRenderer.vue",
      "_index.0H1nq9AP.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentDoc.vue",
      "_query.BOJ__k2B.js",
      "_preview.CxuQdA9n.js",
      "_ContentRendererMarkdown.vue.CBVWc_lB.js",
      "_index.BsYmvPZw.js",
      "_index.Cw5xeYJd.js",
      "node_modules/@nuxt/content/dist/runtime/components/ContentQuery.vue",
      "_asyncData.NVQsfYZl.js"
    ]
  },
  "pages/p/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Dr5NK0j8.js",
    "src": "pages/p/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/record.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "record.CiM5ub2Y.js",
    "src": "pages/record.vue",
    "isDynamicEntry": true,
    "imports": [
      "_SubNav.vue.CutUwA-u.js",
      "_PostList.vue.BJAgizMw.js",
      "_index.DmQH33Or.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Cell.vue.B4kp0Hed.js",
      "_nuxt-link.B5TFTaXi.js",
      "_query.BOJ__k2B.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "pages/search.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "search.CuXds2iu.js",
    "src": "pages/search.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Cell.vue.B4kp0Hed.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_query.BOJ__k2B.js",
      "_index.Cw5xeYJd.js",
      "_nuxt-link.B5TFTaXi.js",
      "_index.DmQH33Or.js",
      "_preview.CxuQdA9n.js"
    ],
    "css": []
  },
  "search.CnnWLWbJ.css": {
    "file": "search.CnnWLWbJ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/tags/[tag].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_tag_.BiHe7NBr.js",
    "src": "pages/tags/[tag].vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.B5TFTaXi.js",
      "_Cell.vue.B4kp0Hed.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_query.BOJ__k2B.js",
      "_index.DmQH33Or.js",
      "_preview.CxuQdA9n.js"
    ]
  },
  "pages/tags/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.lkCR0oDA.js",
    "src": "pages/tags/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.B5TFTaXi.js",
      "_query.BOJ__k2B.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_preview.CxuQdA9n.js"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
