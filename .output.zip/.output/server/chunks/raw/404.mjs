// ROLLUP_NO_REPLACE 
 const _404 = "{\"parsed\":{\"_path\":\"/404\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"Oops! 404\",\"description\":\"You look like you're looking for something that doesn't exist\",\"body\":{\"type\":\"root\",\"children\":[{\"type\":\"element\",\"tag\":\"h1\",\"props\":{\"id\":\"oops-404\"},\"children\":[{\"type\":\"text\",\"value\":\"Oops! 404\"}]},{\"type\":\"element\",\"tag\":\"p\",\"props\":{},\"children\":[{\"type\":\"text\",\"value\":\"You look like you're looking for something that doesn't exist\"}]}],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:404.md\",\"_source\":\"content\",\"_file\":\"404.md\",\"_extension\":\"md\"},\"hash\":\"TATqmHHm57\"}";

export { _404 as default };
//# sourceMappingURL=404.mjs.map
