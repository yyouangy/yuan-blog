// ROLLUP_NO_REPLACE 
 const jsBasic = "{\"parsed\":{\"_path\":\"/notes/javascript/js-basic\",\"_dir\":\"javascript\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"JavaScript基础\",\"description\":\"\",\"date\":\"2023-06-02T17:55:07.000Z\",\"url\":null,\"aliases\":null,\"body\":{\"type\":\"root\",\"children\":[],\"toc\":{\"title\":\"\",\"searchDepth\":2,\"depth\":2,\"links\":[]}},\"_type\":\"markdown\",\"_id\":\"content:notes:javascript:js-basic.md\",\"_source\":\"content\",\"_file\":\"notes/javascript/js-basic.md\",\"_extension\":\"md\"},\"hash\":\"bndPzi0RsQ\"}";

export { jsBasic as default };
//# sourceMappingURL=js-basic.mjs.map
