// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/404\":[\"content:404.md\"],\"/me\":[\"content:me.md\"],\"/record/example\":[\"content:record:Example.md\"],\"/blog/25-time-saving-tips-for-nuxt3\":[\"content:blog:25-time-saving-tips-for-nuxt3.md\"],\"/blog/clean-code\":[\"content:blog:clean-code.md\"],\"/blog/js-tree-operate\":[\"content:blog:js-tree-operate.md\"],\"/blog/screen-adaptation\":[\"content:blog:screen-adaptation.md\"],\"/blog/what-happens-when-enter-url\":[\"content:blog:what-happens-when-enter-url.md\"],\"/notes/javascript/js-basic\":[\"content:notes:javascript:js-basic.md\"],\"/notes/ts/ts-basic\":[\"content:notes:ts:ts-basic.md\"],\"/notes/ts/ts-senior\":[\"content:notes:ts:ts-senior.md\"],\"/notes/node/ts-basic\":[\"content:notes:node:ts-basic.md\"],\"/notes/vue/component\":[\"content:notes:vue:component.md\"],\"/notes/vue/reactive\":[\"content:notes:vue:reactive.md\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
